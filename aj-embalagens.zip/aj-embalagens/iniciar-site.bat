@echo off
echo ========================================
echo   AJ EMBALAGENS - Servidor Local
echo ========================================
echo.
echo Iniciando servidor...
echo.
cd /d "%~dp0"
python -m http.server 8080
pause
