/* AJ Embalagens — Main JavaScript */

(function () {
  'use strict';

  /* ── Mobile menu ────────────────────────────────────────── */
  const menuToggle = document.querySelector('.menu-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', function () {
      const open = mainNav.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(open));
      const icon = open ? 'close' : 'menu';
      menuToggle.querySelector('svg').setAttribute('data-icon', icon);
    });

    /* Close menu when a nav link is clicked */
    mainNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mainNav.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      /* Close all */
      document.querySelectorAll('.faq-item.open').forEach(function (el) {
        el.classList.remove('open');
      });
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ── Product filter ─────────────────────────────────────── */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');

  filterBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      filterBtns.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      const category = btn.dataset.filter;
      productCards.forEach(function (card) {
        const show = category === 'all' || card.dataset.category === category;
        card.style.display = show ? '' : 'none';
      });
    });
  });

  /* ── Contact form → WhatsApp ───────────────────────────── */
  const quoteForm = document.getElementById('quote-form');
  if (quoteForm) {
    quoteForm.addEventListener('submit', function (e) {
      e.preventDefault();

      var produto = document.getElementById('q-produto');
      var tamanho = document.getElementById('q-tamanho');
      var quantidade = document.getElementById('q-quantidade');
      var cidade = document.getElementById('q-cidade');
      var obs = document.getElementById('q-obs');
      var errors = 0;

      /* Reset errors */
      [produto, tamanho, quantidade, cidade].forEach(function (el) {
        if (el) el.closest('.form-group').classList.remove('error');
      });

      if (!produto.value) {
        produto.closest('.form-group').classList.add('error');
        errors++;
      }
      if (!quantidade.value || parseInt(quantidade.value, 10) < 1) {
        quantidade.closest('.form-group').classList.add('error');
        errors++;
      }
      if (!cidade.value) {
        cidade.closest('.form-group').classList.add('error');
        errors++;
      }

      if (errors) return;

      var prodText = produto.options[produto.selectedIndex].text;
      var tamText = tamanho && tamanho.value ? tamanho.value : '—';
      var qtd = quantidade.value;
      var cid = cidade.value;
      var observacoes = obs ? obs.value.trim() : '';

      var msg = 'Olá! Gostaria de solicitar um orçamento.';
      msg += '\nProduto: ' + prodText;
      msg += '\nTamanho/variação: ' + tamText;
      msg += '\nQuantidade: ' + qtd + ' pacote(s)';
      msg += '\nCidade de entrega: ' + cid;
      if (observacoes) msg += '\nObservações: ' + observacoes;
      msg += '\n\nAguardo retorno. Obrigado(a)!';

      var encoded = encodeURIComponent(msg);
      window.open('https://wa.me/5518886512249?text=' + encoded, '_blank');
    });
  }

  /* ── Product card WhatsApp buttons ─────────────────────── */
  document.querySelectorAll('.product-wpp').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var produto = btn.dataset.produto || '';
      var tamanho = btn.dataset.tamanho || '';
      var cat = btn.dataset.category || '';

      var msg = 'Olá! Gostaria de solicitar um orçamento.';
      msg += '\nProduto: ' + produto;
      if (tamanho) msg += '\nTamanho/variação: ' + tamanho;
      msg += '\nQuantidade: a combinar';
      msg += '\nCidade de entrega: a confirmar';
      msg += '\n\nAguardo retorno. Obrigado(a)!';

      var encoded = encodeURIComponent(msg);
      window.open('https://wa.me/5518886512249?text=' + encoded, '_blank');
    });
  });

  /* ── Header shadow on scroll ───────────────────────────── */
  var header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.style.boxShadow = window.scrollY > 4 ? '0 2px 8px rgba(0,0,0,0.07)' : '';
    });
  }
})();
