# AJ Embalagens - Servidor Local
Set-Location $PSScriptRoot
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AJ EMBALAGENS - Servidor Local" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Acessos:" -ForegroundColor Green
Write-Host "  Computador: http://localhost:8080" -ForegroundColor White
Write-Host "  Celular (mesma rede Wi-Fi): http://<IP>:8080" -ForegroundColor White
Write-Host ""
Write-Host "Para encontrar seu IP, execute:" -ForegroundColor Yellow
Write-Host "  ipconfig" -ForegroundColor Gray
Write-Host ""
python -m http.server 8080
