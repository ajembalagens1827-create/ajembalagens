# AJ EMBALAGENS — Site Institucional

## Como abrir o site

### Opção 1 — No computador
Abra o arquivo `index.html` diretamente no navegador (duplo clique).

### Opção 2 — Servidor local (recomendado)
Execute um dos arquivos abaixo na pasta do projeto:
- `iniciar-site.bat` (Windows, usa Python)
- `iniciar-site.ps1` (PowerShell)

Depois acesse: **http://localhost:8080**

### Opção 3 — No celular (mesma rede Wi-Fi)
1. Inicie o servidor (Opção 2)
2. Descubra o IP do computador: abra o Prompt de Comando e digite `ipconfig`, procure por "Endereço IPv4"
3. No celular, acesse: **http://<IP_DO_COMPUTADOR>:8080**

---

## Estrutura do projeto

```
aj-embalagens/
├── index.html              # Página inicial
├── sobre.html              # Sobre a empresa
├── produtos.html           # Catálogo com filtros
├── entregas.html           # Área de entrega
├── contato.html            # Contato + formulário orçamento
├── css/
│   └── style.css           # Estilos completos
├── js/
│   ├── data.js             # Dados da empresa (atualizar aqui!)
│   └── main.js             # Funcionalidades (menu, filtros, WhatsApp)
├── images/
│   ├── brand/
│   │   └── logo-aj.svg     # Logotipo (SVG)
│   └── products/
│       ├── saco-lixo-20l.png
│       ├── saco-lixo-30l.png
│       ├── saco-lixo-40l.png
│       ├── saco-lixo-60l.png
│       ├── saco-lixo-100l.png
│       └── saco-lixo-200l.png  # Placeholder (use imagem genérica)
└── iniciar-site.bat        # Script para rodar servidor local
```

---

## O que precisa ser atualizado

### 1. URL do Facebook (obrigatório para link funcionar)
Abra `js/data.js` e altere:
```js
facebookUrl: "", // PREENCHER com a URL oficial do Facebook
```
para:
```js
facebookUrl: "https://www.facebook.com/NOME-DO-PERFIL",
```

### 2. Logotipo em PNG (opcional)
Se o proprietário enviar o logotipo em PNG, coloque em `images/brand/logo-aj.png`
e atualize as referências nos HTMLs.

### 3. Imagens de produtos faltantes
Adicione as imagens na pasta `images/products/` com os nomes:
- `sacola-30x40.png`, `sacola-35x45.png`, `sacola-40x50.png`, `sacola-45x55.png`, `sacola-60x80.png`
- `pano-xadrez.png`, `pano-branco.png`, `flanela.png`
- `rodinho-grande.png`, `rodinho-pequeno.png`, `vassoura-caipira.png`

Depois atualize o array `produtos` em `js/data.js`:
- Troque `img: null` por `img: "images/products/nome-do-arquivo.png"`
- Remova a linha `"placeholder": true`

### 4. Logo PNG (se disponível)
Copiar para `images/brand/logo-aj.png` e atualizar os `<img>` nos HTMLs.

---

## Tecnologias

- HTML5 semântico
- CSS3 com variáveis CSS (sem framework)
- JavaScript vanilla (sem bibliotecas)
- Fontes: Inter (Google Fonts)
- Ícones: SVG inline
- Acessível (ARIA labels, foco visível, reduced motion)
